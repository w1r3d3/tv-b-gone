typedef struct codeElement {
  unsigned int onTime;   // duration of "On" time
  unsigned int offTime;  // duration of "Off" time
} codestruct;
